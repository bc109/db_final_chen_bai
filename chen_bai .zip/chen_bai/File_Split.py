import pandas as pd
import os
import glob

# # #Select what we need from the original csv file
d1 = pd.read_csv('/Users/baichen/Desktop/US_Accidents_June20.csv', encoding='UTF-8',usecols=[0,3,4,6,7,11,14,15,16,17,18,19,23,24,25,27,28,29,31,32,33,34,35,36,37,38,39,40,41,42,43,44])
d1.to_csv('/Users/baichen/Desktop/US_accident.csv', index = False)

# # #Create Accident_Sign.csv which contains SignID and related attributes
ds = pd.read_csv('/Users/baichen/Desktop/US_Accident.csv', encoding='UTF-8',usecols=[19,20,21,22,23,24,25,26,27,28,29,30,31])
ds = ds.drop_duplicates()
SI = []
for i in range(1, len(ds)+1):
    SI.append('SI' + str(i))
ds.insert(0,'SI_ID', SI)
ds.to_csv('/Users/baichen/Desktop/Accident_Sign.csv', index = False)

# # #Create Accident_Weather.csv which contains WeatherID and related attributes
dw = pd.read_csv('/Users/baichen/Desktop/US_Accident.csv', encoding='UTF-8',usecols=[12,13,14,15,16,17,18])
WI = []
for i in range(1, len(dw)+1):
    WI.append('WI' + str(i))
dw.insert(0,'WI_ID', WI)
dw.to_csv('/Users/baichen/Desktop/Accident_Weather.csv', index = False)

#Create Accident_Area.csv which contains AreaID and related attributes
da = pd.read_csv('/Users/baichen/Desktop/US_Accident.csv', encoding='UTF-8',usecols=[3,4,7,8,9,11])
AI = []
for i in range(1, len(da)+1):
    AI.append('AI' + str(i))
da.insert(0,'AI_ID', AI)
da.to_csv('/Users/baichen/Desktop/Accident_Area.csv', index = False)


# #Create Accident.csv which contains AreaID, WeatherID, SignID and other original related attributes
# Open US_accident.csv
data = pd.read_csv('/Users/baichen/Desktop/US_accident.csv')
# Each csv file should contain 100,000 rows, so 3,500,000+ should split into 360 files.
for i in range(352):
    save_data = data.iloc[i*10000 : (i+1)*10000]
    file_name = '/Users/baichen/Desktop/split_file/US_accident' + str(i) + '.csv'  # 保存文件路径以及文件名称
    save_data.to_csv(file_name, index=False)

for i in range(352):
    file_name = '/Users/baichen/Desktop/split_file/US_accident' + str(i) + '.csv'
    d = pd.read_csv(file_name, encoding='UTF-8')
    AI,WI = [],[]
    for j in range(1, len(d) + 1):
        AI.append('AI' + str(i*len(d)+j))
        WI.append('WI' + str(i*len(d)+j))
    d.insert(32, 'AI_ID', AI)
    d.insert(33, 'WI_ID', WI)
    d.to_csv(file_name, encoding='UTF-8', index = False)

#Create Accident.csv which contains AreaID, WeatherID, SignID and other original related attributes
ds = pd.read_csv('/Users/baichen/Desktop/Accident_Sign.csv', encoding='UTF-8')

for i in range(352):
    file_name = '/Users/baichen/Desktop/split_file/US_accident' + str(i) + '.csv'
    dc = pd.read_csv(file_name, encoding='UTF-8')
    r1 = pd.merge(dc, ds, on = ['Amenity','Bump','Crossing','Give_Way','Junction','No_Exit','Railway','Roundabout', 'Station','Stop','Traffic_Calming','Traffic_Signal', 'Turning_Loop'])
    r1.to_csv(file_name, index = False)

for i in range(352):
    file_name = '/Users/baichen/Desktop/split_file/US_accident' + str(i) + '.csv'
    d = pd.read_csv(file_name, encoding='UTF-8', usecols=[0,1,2,5,6,32,33,34])
    d.to_csv(file_name, index = False)


path = '/Users/baichen/Desktop/split_file'

all_files = glob.glob(os.path.join(path, 'US_accident*.csv'))
df_from_each_file = (pd.read_csv(f) for f in all_files)
df_merged = pd.concat(df_from_each_file, ignore_index=True)
df_merged.to_csv('/Users/baichen/Desktop/US_Accidents.csv', index = False)
