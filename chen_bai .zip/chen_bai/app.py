from flask import Flask, request, redirect, render_template
import pandas as pd
import pymysql
from itertools import chain

app = Flask(__name__)
app.config['DEBUG'] = True

# Connect the mysql database
dbcon = pymysql.connect(
    host='localhost',
    user='root',
    password='Bc971009$$',
    db='db_test',
    # port = 3306,
    charset='utf8'
)

def tuple_to_list(query_result):
    state_dic = {'AL': 'ALABAMA',
                 'AK': 'ALASKA',
                 'AZ': 'ARIZONA',
                 'AR': 'ARKANSAS',
                 'CA': 'CALIFORNIA',
                 'CO': 'COLORADO',
                 'CT': 'CONNECTICUT',
                 'DC': 'DISTRICT OF COLUMBIA',
                 'DE': 'DELAWARE',
                 'FL': 'FLORIDA',
                 'GA': 'GEORGIA',
                 'HI': 'HAWAII',
                 'ID': 'IDAHO',
                 'IL': 'ILLINOIS',
                 'IN': 'INDIANA',
                 'IA': 'IOWA',
                 'KS': 'KANSAS',
                 'KY': 'KENTUCKY',
                 'LA': 'LOUISIANA',
                 'ME': 'MAINE',
                 'MD': 'MARYLAND',
                 'MA': 'MASSACHUSETTS',
                 'MI': 'MICHIGAN',
                 'MN': 'MINNESOTA',
                 'MS': 'MISSISSIPPI',
                 'MO': 'MISSOURI',
                 'MT': 'MONTANA',
                 'NE': 'NEBRASKA',
                 'NV': 'NEVADA',
                 'NH': 'NEW HAMPSHIRE',
                 'NJ': 'NEW JERSEY',
                 'NM': 'NEW MEXICO',
                 'NY': 'NEW YORK',
                 'NC': 'NORTH CAROLINA',
                 'ND': 'NORTH DAKOTA',
                 'OH': 'OHIO',
                 'OK': 'OKLAHOMA',
                 'OR': 'OREGON',
                 'PA': 'PENNSYLVANIA',
                 'RI': 'RHODE ISLAND',
                 'SC': 'SOUTH CAROLINA',
                 'SD': 'SOUTH DAKOTA',
                 'TN': 'TENNESSEE',
                 'TX': 'TEXAS',
                 'UT': 'UTAH',
                 'VT': 'VERMONT',
                 'VA': 'VIRGINIA',
                 'WA': 'WASHINGTON',
                 'WV': 'WEST VIRGINIA',
                 'WI': 'WISCONSIN',
                 'WY': 'WYOMING'
                 }
    result_list = []
    for ele in query_result:
        result_list.append((state_dic[ele[0]], ele[1]))
    return result_list

#HomePage
@app.route('/', methods=['GET'])
def home():
    return render_template('HomePage.html')

#Query1
@app.route('/query1', methods=['POST'])
def query1():
    year1 = request.form['q1year1']
    year2 = request.form['q1year2']
    cursor = dbcon.cursor()
    sql = 'SELECT State, COUNT(R1.AI_ID) as State_number ' \
          'FROM '\
          '(SELECT Accident.AI_ID, State '\
          'FROM Accident, Area '\
          'WHERE Accident.AI_ID = Area.AI_ID AND year(Accident.Start_Time) between %s and %s) R1 '\
          'GROUP BY State ' \
          'ORDER BY COUNT(R1.AI_ID); '\

    data = (year1, year2)
    cursor.execute(sql, data)
    results = cursor.fetchall()
    results = tuple_to_list(results)
    print(results)
    return render_template('Q1.html', results=results)

#Query2
@app.route('/query2', methods=['POST'])
def query2():
    state = request.form['q2state']
    cursor = dbcon.cursor()
    sql = 'SELECT COUNT(ID) as A_number ' \
          'FROM ' \
          '(SELECT Accident.ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE year(Start_Time) = "2016" AND State = %s AND Accident.AI_ID = Area.AI_ID) R1 ' \
          'GROUP BY month(Start_Time) ' \
          'ORDER BY month(Start_Time); '

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2016 = list(chain(*results))
    print(r2016)

    sql = 'SELECT COUNT(ID) as A_number ' \
          'FROM ' \
          '(SELECT Accident.ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE year(Start_Time) = "2017" AND State = %s AND Accident.AI_ID = Area.AI_ID) R1 ' \
          'GROUP BY month(Start_Time) ' \
          'ORDER BY month(Start_Time); '

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2017 = list(chain(*results))
    print(r2017)

    sql = 'SELECT COUNT(ID) as A_number ' \
          'FROM ' \
          '(SELECT Accident.ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE year(Start_Time) = "2018" AND State = %s AND Accident.AI_ID = Area.AI_ID) R1 ' \
          'GROUP BY month(Start_Time) ' \
          'ORDER BY month(Start_Time); '

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2018 = list(chain(*results))
    print(r2018)

    sql = 'SELECT COUNT(ID) as A_number ' \
          'FROM ' \
          '(SELECT Accident.ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE year(Start_Time) = "2019" AND State = %s AND Accident.AI_ID = Area.AI_ID) R1 ' \
          'GROUP BY month(Start_Time) ' \
          'ORDER BY month(Start_Time); '

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2019 = list(chain(*results))
    print(r2019)

    sql = 'SELECT COUNT(ID) as A_number ' \
          'FROM ' \
          '(SELECT Accident.ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE year(Start_Time) = "2020" AND State = %s AND Accident.AI_ID = Area.AI_ID) R1 ' \
          'GROUP BY month(Start_Time) ' \
          'ORDER BY month(Start_Time); '

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2020 = list(chain(*results))
    print(r2020)


    return render_template('Q2.html', state=state, r2016=r2016, r2017=r2017, r2018=r2018, r2019=r2019, r2020=r2020)

#Query3
@app.route('/query3', methods=['POST'])
def query3():
    state = request.form['q3state']
    cursor = dbcon.cursor()
    sql = 'SELECT COUNT(ID) ' \
          'FROM ' \
          '(SELECT ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE Severity = 1 AND Accident.AI_ID = Area.AI_ID AND Area.State = %s) R1 ' \
          'GROUP BY year(Start_Time) ' \
          'ORDER BY year(Start_Time)'

    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r1 = list(chain(*results))
    print(r1)

    sql = 'SELECT COUNT(ID)' \
          'FROM ' \
          '(SELECT ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE Severity = 2 AND Accident.AI_ID = Area.AI_ID AND Area.State = %s) R1 ' \
          'GROUP BY year(Start_Time) ' \
          'ORDER BY year(Start_Time)'
    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r2 = list(chain(*results))
    print(r2)

    sql = 'SELECT COUNT(ID)' \
          'FROM ' \
          '(SELECT ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE Severity = 3 AND Accident.AI_ID = Area.AI_ID AND Area.State = %s) R1 ' \
          'GROUP BY year(Start_Time) ' \
          'ORDER BY year(Start_Time)'
    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r3 = list(chain(*results))
    print(r3)

    sql = 'SELECT COUNT(ID) ' \
          'FROM ' \
          '(SELECT ID, Start_Time ' \
          'FROM Accident, Area ' \
          'WHERE Severity = 4 AND Accident.AI_ID = Area.AI_ID AND Area.State = %s) R1 ' \
          'GROUP BY year(Start_Time) ' \
          'ORDER BY year(Start_Time)'
    cursor.execute(sql, state)
    results = cursor.fetchall()
    results = list(results)
    for re in results:
        results[results.index(re)] = list(re)
    r4 = list(chain(*results))
    print(r4)

    return render_template('Q3.html', state=state, r1=r1, r2=r2, r3=r3, r4=r4)


#Query4
@app.route('/query4', methods=['POST'])
def query4():
    severity = request.form['q4severity']
    cursor = dbcon.cursor()
    sql = 'SELECT Weather_Condition,AVG(Temperature), AVG(Wind_Chill), AVG(Humidity), AVG(Visibility), AVG(Wind_Speed) ' \
          'FROM ' \
          '(SELECT Weather.WI_ID, Weather_Condition, Temperature, Wind_Chill, Humidity, Visibility, Wind_Speed ' \
          'FROM Accident, Weather ' \
          'WHERE Severity = %s  AND Accident.WI_ID = Weather.WI_ID AND Weather_Condition IN ' \
          '(SELECT Weather_Condition ' \
          'FROM ' \
          '(SELECT Weather_Condition ' \
          'FROM ' \
          '(SELECT Weather.WI_ID, Weather_Condition, Temperature, Wind_Chill, Humidity, Visibility, Wind_Direction, Wind_Speed ' \
          'FROM Accident, Weather ' \
          'WHERE Severity = %s  AND Accident.WI_ID = Weather.WI_ID) R1 ' \
          'GROUP BY Weather_Condition ' \
          'ORDER BY COUNT(R1.WI_ID) DESC LIMIT 0, 1) R2)) R3 ' \
          'GROUP BY Weather_Condition '
    data = (severity, severity)
    cursor.execute(sql, data)
    results = cursor.fetchall()
    return render_template('Q4.html', severity=severity, results = results)


#Query5
@app.route('/query5', methods=['POST'])
def query5():
    cursor = dbcon.cursor()
    sql = 'SELECT Amenity, Bump, Crossing, Give_Way, Junction, No_Exit, Railway, Roundabout, Station, Stop, Traffic_Calming, Traffic_Signal, Turning_Loop ' \
          'FROM Sign ' \
          'WHERE SI_ID IN ' \
          '(SELECT SI_ID ' \
          'FROM ' \
          '(SELECT SI_ID ' \
          'FROM Accident ' \
          'GROUP BY SI_ID ' \
          'ORDER BY COUNT(ID) ASC LIMIT 0, 5) R1) '
    cursor.execute(sql)
    results = cursor.fetchall()
    return render_template('Q5.html', results = results)


if __name__ == '__main__':
    app.run(host='0,0,0,0', port=5000, debug=True)
