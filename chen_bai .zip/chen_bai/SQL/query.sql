/* No.1 */
#Which State had the greatest number of accidents among the year? (@year) Can be visualized. Build a map.

SELECT COUNT(R1.AI_ID) as State_number, State
FROM
(SELECT Accident.AI_ID, State
FROM Accident, Area
WHERE Accident.AI_ID = Area.AI_ID AND year(Accident.Start_Time) = 2020) R1
GROUP BY State;

#year(), month(), day()

#Specific time or day
SELECT Accident.AI_ID, State
FROM Accident, Area
WHERE Accident.AI_ID = Area.AI_ID AND year(Accident.Start_Time) = 2019 AND month(Accident.Start_Time) = 08 AND day(Accident.Start_Time) = 21 AND hour(Accident.Start_Time) = 19 AND minute(Accident.Start_Time) = 10

# A range of time
SELECT Start_Time
FROM Accident
WHERE Start_Time between '2019-01-01' and '2020-01-01'


/* No.2 */
#What kind of severity of the accident happened most among the range of time in specific states? 


SELECT Severity
FROM
(SELECT ID, Severity, City
FROM Accident, Area
WHERE Accident.AI_ID = Area.AI_ID AND year(Accident.Start_Time) = 2019 AND Area.State = 'NY') R1
GROUP BY Severity
ORDER BY COUNT(ID) DESC LIMIT 0, 1



/* No.3 */
#List the top3 kind of style of POI annotation which the fewest accidents happended among these year.
SELECT * 
FROM Sign
WHERE SI_ID IN
(SELECT SI_ID
FROM
(SELECT SI_ID
FROM Accident
GROUP BY SI_ID
ORDER BY COUNT(ID) ASC LIMIT 0, 3) R1)



/* No.4 */
#List the top3 months with accidents number in the year which had the most accidents. @2020

SELECT month(R1.Start_Time), COUNT(ID)
FROM
(SELECT ID, Start_Time
FROM Accident
WHERE year(Start_Time) = 2020) R1
GROUP BY month(Accident.Start_Time)
ORDER BY COUNT(ID) DESC LIMIT 0, 3


/* No.5 */
#List the county name which have the fewest number of accidents and the most accidents among these years. None @

(SELECT County, COUNT(AI_ID)
FROM Area
GROUP BY County
HAVING COUNT(AI_ID) IN
(SELECT n
FROM
(SELECT COUNT(AI_ID) as n
FROM Area
GROUP BY County
ORDER BY COUNT(AI_ID) ASC LIMIT 0, 1) R1))
UNION
(SELECT County, COUNT(AI_ID)
FROM Area
GROUP BY County
HAVING COUNT(AI_ID) IN
(SELECT n
FROM
(SELECT COUNT(AI_ID) as n
FROM Area
GROUP BY County
ORDER BY COUNT(AI_ID) DESC LIMIT 0, 1) R2))



/* No.6 */
#List the accidents happened in right side and left side in the states among these year. @MD
SELECT *
FROM
(SELECT COUNT(ID) as leftside_num, Side
FROM Accident, Area
WHERE Accident.Side = 'L' AND Area.State = 'MD' AND Accident.AI_ID = Area.AI_ID) R1,
(SELECT COUNT(ID) as rightside_num, Side
FROM Accident, Area
WHERE Accident.Side = 'R' AND Area.State = 'MD' AND Accident.AI_ID = Area.AI_ID) R2


/* No.7 */
# Draw a line chart of the number of accidents of the month of each year. @08

SELECT COUNT(ID) as A_number, year(Start_Time) as year
FROM
(SELECT Accident.ID, Start_Time
FROM Accident, Area
WHERE month(Start_Time) = '08' AND State = 'NY' AND Accident.AI_ID = Area.AI_ID) R1
GROUP BY year(Start_Time) 
ORDER BY year(Start_Time) 

/* No.8 */
# Draw a line chart of the number of accidents happened in each month of the year @2019
SELECT COUNT(ID), month(Start_Time)
FROM
(SELECT ID, Start_Time
FROM Accident
WHERE year(Start_Time) = '2019') R1
GROUP BY month(Start_Time) 
ORDER BY month(Start_Time)


/* No.9 */
# Draw a bar chart of the number of accidents happened in each weather condition of the year @2019

SELECT COUNT(ID), Weather_Condition
FROM
(SELECT ID, Weather_Condition
FROM Accident, Weather
WHERE Accident.WI_ID = Weather.WI_ID AND year(Start_Time) = '2019' AND Weather.Weather_Condition <> '') R1
GROUP BY Weather_Condition
ORDER BY COUNT(ID) DESC

/* No.10 */
# Among the accidents which severity is highest(4), which kind of weather condition the accident suffer most? List the specific average content of weather.

SELECT Weather_Condition,AVG(Temperature), AVG(Wind_Chill), AVG(Humidity), AVG(Visibility), AVG(Wind_Speed)
FROM
(SELECT Weather.WI_ID, Weather_Condition, Temperature, Wind_Chill, Humidity, Visibility, Wind_Speed
FROM Accident, Weather
WHERE Severity = 4  AND Accident.WI_ID = Weather.WI_ID AND Weather_Condition IN
(SELECT Weather_Condition
FROM
(SELECT Weather_Condition
FROM
(SELECT Weather.WI_ID, Weather_Condition, Temperature, Wind_Chill, Humidity, Visibility, Wind_Direction, Wind_Speed
FROM Accident, Weather
WHERE Severity = 4  AND Accident.WI_ID = Weather.WI_ID) R1
GROUP BY Weather_Condition 
ORDER BY COUNT(R1.WI_ID) DESC LIMIT 0, 1) R2)) R3
GROUP BY Weather_Condition

/* No.11 */
#Which date has the greatest/fewest number of accidents among the year in the country?

(SELECT *
FROM
(SELECT year(Start_Time), month(Start_Time), day(Start_Time), COUNT(Accident.ID) as n
FROM Accident
GROUP BY year(Start_Time), month(Start_Time), day(Start_Time))Q1
WHERE n IN
(SELECT *
FROM
(SELECT COUNT(ID)
FROM Accident
GROUP BY year(Start_Time), month(Start_Time), day(Start_Time)
ORDER BY COUNT(ID) ASC LIMIT 0, 1) R1))
UNION
(SELECT *
FROM
(SELECT year(Start_Time), month(Start_Time), day(Start_Time), COUNT(Accident.ID) as n
FROM Accident
GROUP BY year(Start_Time), month(Start_Time), day(Start_Time))Q2
WHERE n IN
(SELECT *
FROM
(SELECT COUNT(ID)
FROM Accident
GROUP BY year(Start_Time), month(Start_Time), day(Start_Time)
ORDER BY COUNT(ID) DESC LIMIT 0, 1) R2))




/* No.12 */
# Limit the windspeed, temperature, severity, show the description of the accidents. @5 @35 @ 3
SELECT Description, Wind_Speed, Temperature, Severity
FROM Weather, Accident
WHERE Wind_Speed > 2 AND Wind_Speed < 5 AND Temperature > 35 AND Temperature < 50 AND Severity < 5  AND Severity > 2 AND Weather.WI_ID = Accident.WI_ID

/* No.13 */
# In the "Snow" condition, list the accidents number and States
SELECT COUNT(AI_ID) as number, 'All Snow Weather' as Weather_Condition, State
FROM
(SELECT Area.AI_ID, Weather_Condition, State
FROM Weather, Accident, Area
WHERE Weather_Condition LIKE '%Snow%' AND Weather.WI_ID = Accident.WI_ID AND Accident.AI_ID = Area.AI_ID) R1
GROUP BY State



/* No.14 */
# In the "W" condition of wind direction, list the accidents number and States
SELECT COUNT(AI_ID) as number, 'All w direction' as Wind_Direction, State
FROM
(SELECT Area.AI_ID, Wind_Direction, State
FROM Weather, Accident, Area
WHERE Wind_Direction LIKE '%W%' AND Weather.WI_ID = Accident.WI_ID AND Accident.AI_ID = Area.AI_ID) R1
GROUP BY State


/* No.15 */
#The weather condition of the specific state
SELECT COUNT(R1.WI_ID), Weather_Condition
FROM
(SELECT Weather.WI_ID, Weather_Condition
FROM Weather, Accident, Area
WHERE Weather.WI_ID = Accident.WI_ID AND Accident.AI_ID = Area.AI_ID AND Area.State = 'MD' AND Weather_Condition <> '') R1
GROUP BY Weather_Condition


SELECT COUNT(ID), year(Start_Time)
FROM
(SELECT ID, Start_Time
FROM Accident, Area
WHERE Severity = 2 AND Accident.AI_ID = Area.AI_ID AND Area = 'NY') R1
GROUP BY year(Start_Time)




SELECT DISTINCT Severity
FROM Accident

SELECT DISTINCT State
FROM Area










