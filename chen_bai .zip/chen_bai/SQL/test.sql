CREATE TABLE user(
	ID INTEGER primary key NOT NULL,
	Username VARCHAR(10),
	Password VARCHAR(10)
);

INSERT INTO user (ID,Username,Password) VALUES (0, 'baichen', '123');

CREATE TABLE Area(
	AI_ID VARCHAR(10) primary key NOT NULL,
	Start_Lat DECIMAL(8,6),
	Start_Lng DECIMAL(8,6),
	City VARCHAR(20),
	County VARCHAR(20),
	State VARCHAR(2),
	Country VARCHAR(2)
);

LOAD DATA LOCAL INFILE '/Users/baichen/Desktop/Accident_Area.csv'
INTO TABLE Area
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(AI_ID,Start_Lat,Start_Lng,City,County,State,Country);


CREATE TABLE Weather(
	WI_ID VARCHAR(10) primary key NOT NULL,
	Temperature DECIMAL(4,1),
	Wind_Chill DECIMAL(4,1),
	Humidity INTEGER,
	Visibility INTEGER,
	Wind_Direction VARCHAR(5),
	Wind_Speed DECIMAL(4,1),
	Weather_Condition VARCHAR(20)
);

LOAD DATA LOCAL INFILE '/Users/baichen/Desktop/Accident_Weather.csv'
INTO TABLE Weather
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(WI_ID,Temperature,Wind_Chill,Humidity,Visibility,Wind_Direction,Wind_Speed,Weather_Condition);



CREATE TABLE Sign(
	SI_ID VARCHAR(10) primary key NOT NULL,
	Amenity BOOLEAN,
	Bump BOOLEAN,
	Crossing BOOLEAN,
	Give_Way BOOLEAN,
	Junction BOOLEAN,
	No_Exit BOOLEAN,
	Railway BOOLEAN,
	Roundabout BOOLEAN,
	Station BOOLEAN,
	Stop BOOLEAN,
	Traffic_Calming BOOLEAN,
	Traffic_Signal BOOLEAN,
	Turning_Loop BOOLEAN
);

LOAD DATA LOCAL INFILE '/Users/baichen/Desktop/Accident_Sign.csv'
INTO TABLE Sign
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(SI_ID, Amenity, Bump,Crossing,Give_Way,Junction,No_Exit,Railway,Roundabout,Station,Stop,Traffic_Calming,Traffic_Signal,Turning_Loop);



CREATE TABLE Accident(
	ID VARCHAR(10) primary key NOT NULL,
	Severity INTEGER,
	Start_Time DateTime,
	Description VARCHAR(100),
	Side VARCHAR(2),
	AI_ID VARCHAR(10),
	WI_ID VARCHAR(10),
	SI_ID VARCHAR(10)
);


LOAD DATA LOCAL INFILE '/Users/baichen/Desktop/US_Accidents.csv'
INTO TABLE Accident
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(ID,Severity,Start_Time,Description,Side,AI_ID,WI_ID,SI_ID);


